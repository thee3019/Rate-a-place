import { React, useEffect, useState } from 'react';
import { Card, Row, Col, Container, Button } from "react-bootstrap";
import {Route, Link} from 'react-router-dom';
import '../components/places/PlacesListCss.css';
import PlacesDetails from '../components/places/PlacesDetails.js';

const PlacesList = () => {
    const [places, setPlaces] = useState([]);
    const fetchURL = "http://localhost:9000/places";
             const fetchData = async () => {
               console.log("Inside fetchData");
               await fetch(fetchURL)
                                    .then(response => response.json())
                                    .then(data => {
                                                    setPlaces(data);
                                                    console.log(data);
                                                    });

             }
             useEffect(() => {
                         console.log("Inside useEffect");
                         fetchData();
                     }, []);

    var link;
    if(sessionStorage.getItem("id")) {
        link='/placesadd';
    } else {
        link = '/signin';
    }
  return (
    <>
      <div class="body">
      <center>
        <h1>List of PLaces</h1>
        <h4>Cannot find the place? Add here </h4> <Link to={link}><Button variant="info"> Add new place </Button></Link>
        <h1></h1>
      </center>
            {places.length > 0 && (
              <Container>
                          <Row>
                              {places.map((place) => (
                                  <Col key={place.id} xs={80} md={4} lg={1000}>
                                      <Card className='mt-5'>
                                          <Card.Body>
                                              <Card.Title>{place.name}</Card.Title>
                                              <Card.Text>{place.tag}</Card.Text>
                                              <Card.Text>{place.category}, {place.city}</Card.Text>
                                              <Link to={`/places/${place.id}`}>
                                                    <Button variant="info">See place</Button>
                                              </Link>
                                          </Card.Body>
                                      </Card>
                                  </Col>
                              ))}

                          </Row>


                      </Container>
            )}
          </div>

    </>
  );
};

export default PlacesList;