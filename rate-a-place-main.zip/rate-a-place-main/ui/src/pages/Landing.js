import React from "react";
import TopNavbar from "../components/navbars/TopNavbar";


export default function Landing() {
  return (
    <>
      <TopNavbar />
    </>
  );
}