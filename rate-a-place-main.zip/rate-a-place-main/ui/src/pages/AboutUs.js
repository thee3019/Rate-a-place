import React from 'react';

const AboutUs = () => {
  return (
    <div
      style={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        height: '90vh'
      }}
    >
      <center><h1>About US</h1>
        <h3>User reviews are more significant than ever for businesses and travel destinations these days.
           Personal experiences with a product or a service indicate the level of customer satisfaction.
           Aim - to develop a web interface to mark a location as a public place of interest and categorize the places as hike, long drive, bike ride, etc. </h3>
      </center>
    </div>
  );
};

export default AboutUs;