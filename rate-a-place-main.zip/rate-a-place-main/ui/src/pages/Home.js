import {React, useEffect} from 'react';
import HeroSection from '../components/herosection/HeroSection.js';
import PlacesList from './PlacesList.js';

const Home = () => {
    useEffect(() => {
        var id_val = sessionStorage.getItem("id");
        console.log(id_val);
    },[]);
  return (
    <>
      <HeroSection/>
    </>
  );
};

export default Home;