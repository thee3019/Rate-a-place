import {React, useState} from 'react';
import './App.css';
import {
  Routes,
  Route
} from 'react-router-dom';

import Welcome from './components/Welcome';
import Landing from './pages/Landing.js';
import Home from './pages/Home.js';
import PlacesList from './pages/PlacesList.js';
import AboutUs from './pages/AboutUs.js';
import PlacesAdd from './components/places/PlacesAdd';
import PlacesDetails from './components/places/PlacesDetails';
import SignIn from './components/signin/SignIn';
import SignUp from './components/signup/SignUp';
import SignUpSuccess from './components/signup/SignUpSuccess';


const App = () => {
    const [isLoggedIn, setIsLoggedIn] = useState(false);
console.log(isLoggedIn);
        return (
        <div className="App">
        <Landing/>
         <Routes>
            <Route exact path="/" element={<Home/>} />
            <Route exact path="/aboutus" element={<AboutUs/>} />
            <Route exact path="/signin" element={<SignIn loggedIn={isLoggedIn} setLoggedIn={setIsLoggedIn}/>} />

            <Route exact path="/signup" element={<SignUp/>} />
            <Route exact path="/signupsuccess" element={<SignUpSuccess/>} />

            <Route exact path="/placesadd" element={<PlacesAdd/>} />
            <Route exact path="/places/list" element={<PlacesList/>} />
            <Route exact path="/places/:placeId" element={<PlacesDetails/>} />


            </Routes>
        </div>
          );


}

export default App;
