import React from 'react';
import { Button } from '../button/Button';

import { Link } from 'react-router-dom';

import '../../App.css';
import './HeroSection.css';

function HeroSection() {
var link;
    if(sessionStorage.getItem("id")) {
        link='/';
    } else {
        link = '/signup';
    }
  return (
    <div className="hero-container">
      <h4>Welcome to Rate a Place</h4>
      <h1>Discover, rate and review your favourite places with us!</h1>
      <div className="hero-btns">


        <a class="effect1" href={link}>
             Get started!
            <span class='bg'></span>
        </a>

        <a class="effect1" href='/places/list'>
                     Explore places
                     <span class="bg"></span>
                </a>

      </div>
    </div>
  );
}

export default HeroSection;
