import React from 'react';
import './css/style.css';
import {Link} from 'react-router-dom';

const RegisterFormSuccess = () => {
  return (
    <div className='form-success-container'>
      <h1>
            Congratulations! You have been successfully registered with Rate a Place, <Link to='/signin'> click here</Link> to sign in.
      </h1>
    </div>
  );
};

export default RegisterFormSuccess;