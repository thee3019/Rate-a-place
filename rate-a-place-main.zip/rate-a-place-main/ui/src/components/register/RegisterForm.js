import {React, useState, useEffect} from 'react';
import {Link} from 'react-router-dom';
import validate from './validateInfo';
import './RegisterCss.css';

const RegisterForm = () => {

  const [values, setValues] = useState({
      username: '',
      email: '',
      password: '',
      password2: ''
    });
    const [errors, setErrors] = useState({});
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleChange = e => {
        const { name, value } = e.target;
        setValues({
          ...values,
          [name]: value
        });
      };

    const fetchURL = "http://localhost:9000/users";
         const fetchData = async () => {
           console.log("Inside fetchData");
           const data = await fetch(fetchURL)
                                .then(response => response.json())
                                .then(data => data);
           console.log(data);
         }


    const handleSubmit = e => {
        e.preventDefault();
        const error = validate(values);
        setErrors(error);
        console.log(error);
        console.log(Object.keys(error));
        console.log(values.username, values.email, values.password, values.password2)
        var body = {
                           username: values.username,
                           email: values.email,
                           password: values.password
                         };
        console.log(body);
        let url = "http://localhost:9000/user";
        let headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append("Accept", "application/json");
        headers.append("Access-Control-Allow-origin", url);
        headers.append("Access-Control-Allow-Credentials", "true");
        headers.append("POST", "GET");
        console.log(errors.email);
        console.log(Object.keys(errors).length);
        if(Object.keys(error).length === 0)
        {
            setIsSubmitting(true);
            console.log("set issubmitting to true");
        }
        console.log(isSubmitting);
        if(isSubmitting)
        {
            console.log("inside fetch");
        fetch(url, {
                        headers: headers,
                        method: "POST",
                        body: JSON.stringify(body),
                    })
                    .then((response) => {
                    if (response.ok) {
                            console.log("Response ok!");
                                window.location.href='/signupsuccess';
                                console.log("Redirect");
                            }

                            })

                    .catch(function (error) {
                                  console.log(error);
                                  alert("Registration failed, please try again!");
                    });

        }


        };

    useEffect(() => {
            console.log("Inside useEffect");
            fetchData();
        }, []);

  return (
            <div class="sign-up-bg">
                            <section class="ftco-section">
                            		<div class="container">
                            			<div class="row justify-content-center">
                            				<div class="col-md-6 text-center mb-5">
                            					<h1 class="heading-section">SIGN UP</h1>
                            				</div>
                            			</div>
                            			<div class="row justify-content-center">
                            				<div class="col-md-6 col-lg-4">
                            					<div class="login-wrap p-0">
                            		      	<h3 class="mb-4 text-center">Create your account</h3>
                            		      	<form onSubmit={handleSubmit} class="signin-form" noValidate>
                            		      	    <div class="form-group">
                                                           <input
                                                             className='form-control'
                                                             type='text'
                                                             name='username'
                                                             placeholder='Enter your name'
                                                             value={values.username}
                                                             onChange={handleChange}
                                                           />
                                                      {errors.username && <p class="error-validation">{errors.username}</p>}
                                		        </div>
                            		      		<div class="form-group">
                                                              <input
                                                                className='form-control'
                                                                type='email'
                                                                name='email'
                                                                placeholder='Enter your email'
                                                                value={values.email}
                                                                onChange={handleChange}
                                                              />
                                                              {errors.email && <p class="error-validation">{errors.email}</p>}

                            		      		</div>
                            	                <div class="form-group">
                                                              <input
                                                                className='form-control'
                                                                type='password'
                                                                name='password'
                                                                placeholder='Enter your password'
                                                                value={values.password}
                                                                onChange={handleChange}
                                                              />
                                                              {errors.password && <p class="error-validation">{errors.password}</p>}
                            	                </div>
                            	                <div class="form-group">
                            	                    <input
                                                                className='form-control'
                                                                type='password'
                                                                name='password2'
                                                                placeholder='Confirm your password'
                                                                value={values.password2}
                                                                onChange={handleChange}
                                                              />
                                                              {errors.password2 && <p class="error-validation">{errors.password2}</p>}
                              	                </div>
                            	                <div class="form-group">
                            	            	    <button type="submit" class="form-control btn btn-primary submit px-3">Sign Up</button>
                            	                </div>
                            	                <span className='form-input-login'>
                                                          Already have an account? <Link to='/signin'>Login here</Link>
                                                </span>
                            	            </form>
                            		      </div>
                            				</div>
                            			</div>
                            		</div>
                            	</section>
                        </div>



//
//    <div className='form-container'>
//      <form onSubmit={handleSubmit} className='form' noValidate>
//        <h1>
//          Register yourself with us today!
//        </h1>
//        <div className='form-inputs'>
//          <label className='form-label'>Name</label>
//          <input
//            className='form-input'
//            type='text'
//            name='username'
//            placeholder='Enter your name'
//            value={values.username}
//            onChange={handleChange}
//          />
//          {errors.username && <p>{errors.username}</p>}
//        </div>
//        <div className='form-inputs'>
//          <label className='form-label'>Email</label>
//          <input
//            className='form-input'
//            type='email'
//            name='email'
//            placeholder='Enter your email'
//            value={values.email}
//            onChange={handleChange}
//          />
//          {errors.email && <p>{errors.email}</p>}
//        </div>
//        <div className='form-inputs'>
//          <label className='form-label'>Password</label>
//          <input
//            className='form-input'
//            type='password'
//            name='password'
//            placeholder='Enter your password'
//            value={values.password}
//            onChange={handleChange}
//          />
//          {errors.password && <p>{errors.password}</p>}
//        </div>
//        <div className='form-inputs'>
//          <label className='form-label'>Confirm Password</label>
//          <input
//            className='form-input'
//            type='password'
//            name='password2'
//            placeholder='Confirm your password'
//            value={values.password2}
//            onChange={handleChange}
//          />
//          {errors.password2 && <p>{errors.password2}</p>}
//        </div>
//        <button className='form-input-btn' type='submit'>
//          Sign up
//        </button>
//        <span className='form-input-login'>
//          Already have an account? <Link to='/signin'>Login here</Link>
//        </span>
//      </form>
//    </div>
  );
};

export default RegisterForm;