import {React, useState, useEffect} from 'react';
import {Link} from 'react-router-dom';
import validate from './validateInfo';
import './RegisterForm.css';


const RegisterFormSignup = () => {

  const [values, setValues] = useState({
      username: '',
      email: '',
      password: '',
      password2: ''
    });
    const [errors, setErrors] = useState({});
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleChange = e => {
        const { name, value } = e.target;
        setValues({
          ...values,
          [name]: value
        });
      };

    const fetchURL = "http://localhost:9000/users";
         const fetchData = async () => {
           console.log("Inside fetchData");
           const data = await fetch(fetchURL)
                                .then(response => response.json())
                                .then(data => data);
           console.log(data);
         }


    const handleSubmit = e => {
        e.preventDefault();
        const error = validate(values);
        setErrors(error);
        console.log(error);
        console.log(Object.keys(error));
        console.log(values.username, values.email, values.password, values.password2)
        var body = {
                           username: values.username,
                           email: values.email,
                           password: values.password
                         };
        console.log(body);
        let url = "http://localhost:9000/user";
        let headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append("Accept", "application/json");
        headers.append("Access-Control-Allow-origin", url);
        headers.append("Access-Control-Allow-Credentials", "true");
        headers.append("POST", "GET");
        console.log(errors.email);
        console.log(Object.keys(errors).length);
        if(Object.keys(error).length === 0)
        {
            setIsSubmitting(true);
            console.log("set issubmitting to true");
        }
        console.log(isSubmitting);
        if(isSubmitting)
        {
            console.log("inside fetch");
        fetch(url, {
                        headers: headers,
                        method: "POST",
                        body: JSON.stringify(body),
                    })
                    .then((response) => {
                    if (response.ok) {
                            console.log("Response ok!");
                                window.location.href='/signupsuccess';
                                console.log("Redirect");
                            }

                            })

                    .catch(function (error) {
                                  console.log(error);
                                  alert("Registration failed, please try again!");
                    });

        }


        };

    useEffect(() => {
            console.log("Inside useEffect");
            fetchData();
        }, []);

  return (


    <div className='form-container'>
      <form onSubmit={handleSubmit} className='form' noValidate>
        <h1>
          Register yourself with us today!
        </h1>
        <div className='form-inputs'>
          <label className='form-label'>Name</label>
          <input
            className='form-input'
            type='text'
            name='username'
            placeholder='Enter your name'
            value={values.username}
            onChange={handleChange}
          />
          {errors.username && <p>{errors.username}</p>}
        </div>
        <div className='form-inputs'>
          <label className='form-label'>Email</label>
          <input
            className='form-input'
            type='email'
            name='email'
            placeholder='Enter your email'
            value={values.email}
            onChange={handleChange}
          />
          {errors.email && <p>{errors.email}</p>}
        </div>
        <div className='form-inputs'>
          <label className='form-label'>Password</label>
          <input
            className='form-input'
            type='password'
            name='password'
            placeholder='Enter your password'
            value={values.password}
            onChange={handleChange}
          />
          {errors.password && <p>{errors.password}</p>}
        </div>
        <div className='form-inputs'>
          <label className='form-label'>Confirm Password</label>
          <input
            className='form-input'
            type='password'
            name='password2'
            placeholder='Confirm your password'
            value={values.password2}
            onChange={handleChange}
          />
          {errors.password2 && <p>{errors.password2}</p>}
        </div>
        <button className='form-input-btn' type='submit'>
          Sign up
        </button>
        <span className='form-input-login'>
          Already have an account? <Link to='/signin'>Login here</Link>
        </span>
      </form>
    </div>
  );
};

export default RegisterFormSignup;