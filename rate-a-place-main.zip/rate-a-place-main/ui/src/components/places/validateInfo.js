export default function validateInfo(values) {
  let errors = {};

  if (!values.name) {
    errors.name = 'Name required';
  }
  if (!values.area) {
      errors.area = 'Area required';
    }

  if (!values.city) {
    errors.city = 'City required';
  }
  if (!values.country) {
      errors.country = 'Country required';
    }

  if (!values.zipcode) {
    errors.zipcode = 'Zipcode required';
  }
  if (!values.tag) {
      errors.tag = 'Tag required';
    }

  if (!values.category) {
    errors.category = 'Category required';
  }

  return errors;
}