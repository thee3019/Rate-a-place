import {React, useState, useEffect} from 'react'
import { useParams} from "react-router";
import {Route, Link, Navigate} from 'react-router-dom';
import { Card, Row, Col, Container, Button, Modal } from "react-bootstrap";
import {Rating} from 'react-simple-star-rating';
import { FaStar } from "react-icons/fa";
import { BiUserCircle } from "react-icons/bi";
import star0 from './images/0stars.jpg';
import stars1 from './images/1star.jpg';
import stars2 from './images/2stars.jpg';
import stars3 from './images/3stars.jpg';
import stars4 from './images/4stars.jpg';
import stars5 from './images/5stars.jpg';
import stars6 from './images/halfstar.jpg';
import stars7 from './images/1halfstars.jpg';
import stars8 from './images/2halfstars.jpg';
import stars9 from './images/3halfstars.jpg';
import stars10 from './images/4halfstars.jpg';
import Alert from 'react-bootstrap/Alert'

const PlacesDetails = (props) => {
    const params= useParams();
    console.log("Place id = ",params.placeId);
    var userid = sessionStorage.getItem("id");
    console.log("User id = ",userid);
    const [review, setReview] = useState('');
        const [errors, setErrors] = useState({});
        const [isSubmitting, setIsSubmitting] = useState(false);
      const [stars, setStars] = useState(0);
        const star = Array(5).fill(0)
        console.log(stars);
        const handleClick = value => {
          setStars(value);
        }
     const [show, setShow] = useState(false);
     const [alreadyShow, setAlreadyShow] = useState(false);
    const [users, setUsers] = useState([]);
    const [places, setPlaces] = useState([]);
    const [ratings, setRatings] = useState([]);
    const fetchUsersURL = "http://localhost:9000/users";
             const fetchUsersData = async () => {
               console.log("Inside fetchUsersData");
               const data = await fetch(fetchUsersURL)
                                    .then(response => response.json())
                                    .then(data => {
                                                    setUsers(data);
                                                    console.log(data);
                                    });
             }
        const fetchPlacesURL = "http://localhost:9000/places";
                 const fetchPlacesData = async () => {
                   console.log("Inside fetchPlacesData");
                   await fetch(fetchPlacesURL)
                                        .then(response => response.json())
                                        .then(data => {
                                                        setPlaces(data);
                                                        console.log(data);
                                                        });
                 }

                 const fetchRatingsURL = "http://localhost:9000/ratings";
                                  const fetchRatingsData = async () => {
                                    console.log("Inside fetchRatingsData");
                                    await fetch(fetchRatingsURL)
                                                         .then(response => response.json())
                                                         .then(data => {
                                                                         setRatings(data);
                                                                         console.log(data);
                                                                         });
                                  }

                 useEffect(() => {
                             console.log("Inside useEffect");
                             fetchUsersData();
                             fetchPlacesData();
                             fetchRatingsData();
                         }, []);


                    var today = new Date(),
                        date = today.getFullYear() + '-' + (today.getMonth() + 1) + '-' + today.getDate();
                    var today = new Date(),
                        time = today.getHours() + ':' + today.getMinutes() + ':' + today.getSeconds();
                    var dateTime = date+' '+time;
                    console.log(dateTime);
                 const handleSubmit = e => {
                         e.preventDefault();
                         var body = {
                                            placeId: params.placeId,
                                            userId: userid,
                                            datetime: dateTime,
                                            rating: stars,
                                            review: review
                                          };
                         console.log(body);
                         let url = "http://localhost:9000/rating";
                         let headers = new Headers();
                         headers.append("Content-Type", "application/json");
                         headers.append("Accept", "application/json");
                         headers.append("Access-Control-Allow-origin", url);
                         headers.append("Access-Control-Allow-Credentials", "true");
                         headers.append("POST", "GET");
                         if(stars > 0)
                         {
                             setIsSubmitting(true);
                             console.log("set issubmitting to true");
                         }
                         console.log(isSubmitting);
                         if(isSubmitting)
                         {
                             console.log("inside fetch");
                         fetch(url, {
                                         headers: headers,
                                         method: "POST",
                                         body: JSON.stringify(body),
                                     })
                                     .then((response) => {
                                     if (response.ok) {
                                             console.log("Response ok!");
                                                 window.location.href='/places/'+params.placeId;
                                                 console.log("Redirect");
                                             }

                                             })

                                     .catch(function (error) {
                                                   console.log(error);
                                                   alert("Failed to add rating, please try again!");
                                     });
                         }}
                         var rev = 0;

                         const handleClose = () => {

                         setShow(false)
                         setAlreadyShow(false)};
                             const handleShow = () => {
                                 if(sessionStorage.getItem("id")) {
                                        var rating1 = ratings.map((r) => {
                                        if(r.placeId == params.placeId) {
                                            if(r.userId == userid) {
                                                rev = 1;
                                                console.log("Oops you already added a review to this place!");
                                                setAlreadyShow(true);


                                            }
                                        }

                                        })
                                        if(rev == 0) {
                                               console.log("Inside setShow to true");
                                                setShow(true);
                                        }

                                 } else {
                                     window.location.href='/signin';
                                 }

                             }


var rating1 = ratings.map((r) => {
if(r.userId == userid) {
    const rat = r.userId;
    console.log("User Rat=",rat);
}
})

let array = [];

var rating = ratings.map((r) => {
if(r.placeId == params.placeId) {
    const rat = r.rating;
    console.log("Rat=",rat);
    array.push(rat);

}
})
const l = array.length;

console.log(l);
let sum = 0;
for (let num of array) {
    sum = sum + num
}
console.log(sum);
var avg = sum/l;
avg = avg.toFixed(2);
console.log(avg);

var imgSRC;
const avgImage = () => {

}

  return (
  <>
    <div class="my-container">


         {places.length > 0 && (places.map((place) => (
                                       place.id == params.placeId && (
                                             <div>
                                             <Row>
                                             <Col>
                                                  <h1><b>{place.name}</b></h1>
                                                  {(avg < 0.5) && (<img width="180" src={star0}/>)}
                                                     {(avg >= 0.5 && avg < 1) && (<img width="180" src={stars6}/>)}
                                                     {(avg == 1) && (<img width="150" src={stars1}/>)}
                                                     {(avg > 1 && avg < 1.5) && (<img width="180" src={stars1}/>)}
                                                     {(avg >= 1.5 && avg < 2) && (<img width="180" src={stars7}/>)}
                                                     {(avg == 2) && (<img width="180" src={stars2}/>)}
                                                     {(avg > 2 && avg < 2.5) && (<img width="180" src={stars2}/>)}
                                                     {(avg >= 2.5 && avg < 3) && (<img width="180" src={stars8}/>)}
                                                     {(avg == 3) && (<img width="180" src={stars3}/>)}
                                                     {(avg > 3 && avg < 3.5) && (<img width="180" src={stars3}/>)}
                                                     {(avg >= 3.5 && avg < 4) && (<img width="180" src={stars9}/>)}
                                                     {(avg == 4) && (<img width="180" src={stars4}/>)}
                                                     {(avg > 4 && avg < 4.5) && (<img width="180" src={stars4}/>)}
                                                     {(avg >= 4.5 && avg < 5) && (<img width="180" src={stars10}/>)}
                                                     {(avg == 5) && (<img width="180" src={stars5}/>)}

                                                    <h5 style={{marginLeft: 10}}> {avg} | {l} reviews</h5>
                                                  <h3>{place.tag} | {place.category}</h3>
                                                  <h5>Location: {place.area}, {place.city}, {place.country}. {place.zipcode}</h5>
                                             </Col>
                                             <Col>
                                                  <Button variant="info" onClick={handleShow}>Rate this place?</Button>
                                             </Col>
                                             </Row>
                                                  <Modal show={show} onHide={handleClose}>
                                                       <Modal.Header closeButton>
                                                         <Modal.Title>Add rating and review</Modal.Title>
                                                       </Modal.Header>
                                                       <Modal.Body>
                                                         <center>
                                                           {star.map((_, index) => {
                                                                 return (
                                                                          <FaStar
                                                                              key={index}
                                                                              size={24}
                                                                              onClick={() => handleClick(index + 1)}
                                                                              color={(stars) > index ? colors.orange : colors.grey}
                                                                              style={{
                                                                                       marginRight: 10,
                                                                                       cursor: "pointer"
                                                                                      }}
                                                                          />)
                                                           })}
                                                           <textarea
                                                                placeholder="Share details of your own experience at this place"
                                                                onChange={e => setReview(e.target.value)}
                                                                value={review}
                                                                style={styles.textarea}
                                                           />
                                                         </center>
                                                       </Modal.Body>
                                                       <Modal.Footer>
                                                          <Button variant="secondary" onClick={handleClose}>Close</Button>
                                                          <Button variant="primary" onClick={handleSubmit}>Submit</Button>
                                                       </Modal.Footer>
                                                  </Modal>
                                                  <Modal show={alreadyShow} onHide={handleClose}>
                                                       <Modal.Header closeButton>
                                                            <Modal.Title>Rating already exists</Modal.Title>
                                                       </Modal.Header>
                                                       <Modal.Body>
                                                            Oops! You have already rated this place.
                                                       </Modal.Body>
                                                       <Modal.Footer>
                                                          <Button variant="danger" onClick={handleClose}>Close</Button>
                                                       </Modal.Footer>
                                                  </Modal>
                                                  <h2> Ratings and reviews</h2>
                                             {ratings.length > 0 && (ratings.map((rating) => (
                                                                    params.placeId == rating.placeId && (
                                                                        <div>
                                                                            <Row>
                                                                            {users.length > 0 && (users.map((user) => (
                                                                                rating.userId == user.id && (
                                                                                <div>

                                                                                    <Card border="dark" style={{width: '1000px'}} className="mb-3">
                                                                                       <Card.Body>
                                                                                           <Card.Title><BiUserCircle size={40}/> {user.username} <small className="text-muted">({user.email})</small></Card.Title>

                                                                                           {(rating.rating == 1) && (<img width="150" src={stars1}/>)}
                                                                                           {(rating.rating == 2) && (<img width="150" src={stars2}/>)}
                                                                                           {(rating.rating == 3) && (<img width="150" src={stars3}/>)}
                                                                                           {(rating.rating == 4) && (<img width="150" src={stars4}/>)}
                                                                                           {(rating.rating == 5) && (<img width="150" src={stars5}/>)}
                                                                                           <small className="text-muted">({rating.rating})</small>
                                                                                           <Card.Title>{rating.review}</Card.Title>
                                                                                       </Card.Body>
                                                                                       <Card.Footer>
                                                                                         <small className="text-muted">{rating.datetime}</small>
                                                                                       </Card.Footer>
                                                                                    </Card>
                                                                                    </div>
                                                                                )
                                                                            )))}

                                                                            </Row>
                                                                        </div>

                                                                    )
                                             )))}
                                             </div>
                                       )
                            ))
                     )}
    </div>
  </>
  )
}





//CSS for rating modal
const colors = {
    orange: "#FFBA5A",
    grey: "#a9a9a9"

};
 const styles = {
   container: {
     display: "flex",
     flexDirection: "column",
     alignItems: "center"
   },
   star: {
     display: "flex",
     flexDirection: "row",
   },
   textarea: {
     border: "1px solid #a9a9a9",
     borderRadius: 5,
     padding: 10,
     margin: "20px 0",
     minHeight: 200,
     width: 400
   },
   button: {
     border: "1px solid #a9a9a9",
     borderRadius: 5,
     width: 300,
     padding: 10,
   }
};

export default PlacesDetails;
