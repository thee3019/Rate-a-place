import {React, useState, useEffect } from 'react';
import validate from './validateInfo';
import './css/style.css';
import img from './images/bg1.jpg';
import { Card, Row, Col, Container, Button } from "react-bootstrap";

const PlacesAdd = () => {

    const [values, setValues] = useState({
          name: '',
          area: '',
          city: '',
          country: '',
          zipcode: '',
          tag: '',
          category: ''
        });
        const [errors, setErrors] = useState({});
        const [isSubmitting, setIsSubmitting] = useState(false);

        const handleChange = e => {
            const { name, value } = e.target;
            setValues({
              ...values,
              [name]: value
            });
          };

        const fetchURL = "http://localhost:9000/places";
                 const fetchData = async () => {
                   console.log("Inside fetchData");
                   const data = await fetch(fetchURL)
                                        .then(response => response.json())
                                        .then(data => data);
                   console.log(data);
                 }


            const handleSubmit = e => {
                e.preventDefault();
                const error = validate(values);
                setErrors(error);
                console.log(error);
                console.log(Object.keys(error));
                console.log(values.name, values.area, values.city, values.country, values.zipcode, values.tag, values.category)
                var body = {
                                   name: values.name,
                                   area: values.area,
                                   city: values.city,
                                   country: values.country,
                                   zipcode: values.zipcode,
                                   tag: values.tag,
                                   category: values.category
                                 };
                console.log(body);
                let url = "http://localhost:9000/place";
                let headers = new Headers();
                headers.append("Content-Type", "application/json");
                headers.append("Accept", "application/json");
                headers.append("Access-Control-Allow-origin", url);
                headers.append("Access-Control-Allow-Credentials", "true");
                headers.append("POST", "GET");
                console.log(errors.email);
                console.log(Object.keys(errors).length);
                if(Object.keys(error).length === 0)
                {
                    setIsSubmitting(true);
                    console.log("set issubmitting to true");
                }
                console.log(isSubmitting);
                if(isSubmitting)
                {
                    console.log("inside fetch");
                fetch(url, {
                                headers: headers,
                                method: "POST",
                                body: JSON.stringify(body),
                            })
                            .then((response) => {
                            if (response.ok) {
                                    console.log("Response ok!");
                                        window.location.href='/placeslist';
                                        console.log("Redirect");
                                    }

                                    })

                            .catch(function (error) {
                                          console.log(error);
                                          alert("Registration failed, please try again!");
                            });

                }


                };

            useEffect(() => {
                    console.log("Inside useEffect");
                    fetchData();
                }, []);

  return (
  <div>
  <section class="my-container">
    <div >
        <div class="row justify-content-center">
        <div >
             <div class="wrap">
             <div class="img" style={{backgroundImage: `url(${img})`}}></div>
             <div class="login-wrap p-4 p-md-5">
             <div class="d-flex">
                  <div class="w-100">
                         <h3 class="mb-4">Fill in details about the place</h3>
                  </div>
             </div>
        <form className='signin-form' onSubmit={handleSubmit} noValidate>
        <Row>
            <Col>
            <div className='form-group mt-3'>
                <label className='placeholder'>Name  </label>
                    <input
                        type='text'
                        name='name'
                        className='form-control'
                        placeholder='Enter the place name'
                        value={values.name}
                        onChange={handleChange}>
                    </input>
                    {errors.name && <p class="error-validation">{errors.name}</p>}
            </div>
            </Col>
            </Row>
            <Row>
            <Col>
            <div className='form-group mt-3'>
                <label className='placeholder'>Area  </label>
                    <input
                        type='text'
                        name='area'
                        className='form-control'
                        placeholder='Enter the area of the place'
                        value={values.area}
                        onChange={handleChange}>
                    </input>
                    {errors.area && <p class="error-validation">{errors.area}</p>}
            </div>
            </Col>

            <Col>
            <div className='form-group mt-3'>
                <label className='placeholder'>City  </label>
                    <input
                        type='text'
                        name='city'
                        className='form-control'
                        placeholder='Enter the city'
                        value={values.city}
                        onChange={handleChange}>
                    </input>
                    {errors.city && <p class="error-validation">{errors.city}</p>}
            </div>
            </Col>
            <Col>
            <div className='form-group mt-3'>
                            <label className='placeholder'>Country  </label>
                            <input
                                type='text'
                                name='country'
                                className='form-control'
                                placeholder='Enter the country'
                                value={values.country}
                                onChange={handleChange}>
                            </input>
                            {errors.country && <p class="error-validation">{errors.country}</p>}
            </div>
            </Col>
          </Row>
          <Row>
            <Col>
            <div className='form-group mt-3'>
                <label className='placeholder'>Zipcode  </label>
                    <input
                        type='number'
                        name='zipcode'
                        className='form-control'
                        placeholder='Enter the zipcode'
                        value={values.zipcode}
                        onChange={handleChange}>
                    </input>
                    {errors.zipcode && <p class="error-validation">{errors.zipcode}</p>}
            </div>
            </Col>
            <Col>
            <div className='form-group mt-3'>
                <label className='placeholder'>Tag </label>
                    <input
                        type='text'
                        name='tag'
                        className='form-control'
                        placeholder='Enter the tag(ex. public place of interest,etc)'
                        value={values.tag}
                        onChange={handleChange}></input>
                        {errors.tag && <p class="error-validation">{errors.tag}</p>}
            </div>
            </Col>
            </Row>
            <Row>
            <Col>
            <div className='form-group mt-3'>
                <label className='placeholder'>Category  </label>
                    <input
                        type='text'
                        name='category'
                        className='form-control'
                        placeholder='Enter the category(ex. hike, long drive,etc)'
                        value={values.category}
                        onChange={handleChange}></input>
                        {errors.category && <p class="error-validation">{errors.category}</p>}
            </div>
            </Col>
          </Row>
            <div class="form-group">
            <button className='form-control btn btn-primary rounded submit px-3' type='submit'>Add Place</button>
            </div>
        </form>
        </div>
        </div>
        </div>
        </div>
    </div>
    </section>
    </div>
  )
}

export default PlacesAdd