import React from 'react';

const Welcome = () => {

    return(
      <div>
        <h1>Hello World!</h1>
      </div>
    );

}

export default Welcome;
