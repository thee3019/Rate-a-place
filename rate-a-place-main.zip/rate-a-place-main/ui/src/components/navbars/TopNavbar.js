import React from 'react';
import { Button } from "react-bootstrap";
import {Route, Link} from 'react-router-dom';
import {
  Nav,
  NavLink,
  Bars,
  NavMenu,
  NavBtn,
  NavBtnLink
} from './TopNavbarElements';
import { BsGeoAlt } from "react-icons/bs";
import { FcGlobe } from "react-icons/fc";

const TopNavbar = () => {
const unSetId = () => {
    sessionStorage.removeItem("id");
    window.location.href='/';

};
var id_val = sessionStorage.getItem("id");
        console.log(id_val);

  return (
    <>
      <Nav>
        <NavLink to='/'>
          <BsGeoAlt/>
          <FcGlobe/>
          <h2 style={{ marginLeft: "15px", color: "white" }} className="font20 extraBold">
                        Rate a Place
          </h2>
        </NavLink>
        <Bars />
        <NavMenu>
          <NavLink to='/' activeStyle>
            Home
          </NavLink>
          <NavLink to='/aboutus' activeStyle>
            About us
          </NavLink>
          <NavLink to='/places/list' activeStyle>
            Places
          </NavLink>

          {/* Second Nav */}
          {/* <NavBtnLink to='/sign-in'>Sign In</NavBtnLink> */}
        </NavMenu>
        <NavBtn>

          {(sessionStorage.getItem("id"))? (
                       <NavBtn>
                        <Button variant="info" onClick={unSetId}>Log Out</Button>
                        </NavBtn>
          ): (
          <>
          <NavBtn>
            <Button variant="info" href="/signup">Sign Up</Button>
           </NavBtn>
           <NavBtn>
            <Button variant="info" href="/signin">Sign In</Button>
          </NavBtn>
          </>
          )}
        </NavBtn>
      </Nav>
    </>
  );
};

export default TopNavbar;