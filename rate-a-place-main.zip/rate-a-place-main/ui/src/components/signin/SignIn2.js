import {React, useState, useEffect} from 'react';
import {Link} from 'react-router-dom';
import validate from './validateSignInInfo';


var result;

const SignIn = () => {

  const [values, setValues] = useState({
      email: '',
      password: ''
    });
    const [errors, setErrors] = useState({});

    const handleChange = e => {
        const { name, value } = e.target;
        setValues({
          ...values,
          [name]: value
        });
      };

    const fetchURL = "http://localhost:9000/users";
         const fetchData = async () => {
           console.log("Inside fetchData");
           const data = await fetch(fetchURL)
                                .then(response => response.json())
                                .then(data => data);
           console.log(data);
         }


    const handleSubmit = e => {
        e.preventDefault();
        setErrors(validate(values));
        console.log(values.email, values.password)
        var body = {
                           email: values.email,
                           password: values.password
                         };
        console.log(body);
        let url = "http://localhost:9000/login";
        let headers = new Headers();
        headers.append("Content-Type", "application/json");
        headers.append("Accept", "application/json");
        headers.append("Access-Control-Allow-origin", url);
        headers.append("Access-Control-Allow-Credentials", "true");
        headers.append("POST", "GET");
        fetch(url, {
                        headers: headers,
                        method: "POST",
                        body: JSON.stringify(body),
                    })
                    .then((response) =>
                    response
                                .json()
                                .then((data) => ({
                                  data1: data,
                                }))
                                .then((res) => {
                                  var id = res.data1.id;
                                  console.log(id);
                                  sessionStorage.setItem("id", id);
                                  window.location.href = "/";
                                })

                            )

                    .catch(function (error) {
                                  console.log(error);
                                  alert("Invalid username or password!");
                    });
        };

    useEffect(() => {
            console.log("Inside useEffect");
            fetchData();
        }, []);

  return (
        <div>
                <section class="ftco-section">
                		<div class="container">
                			<div class="row justify-content-center">
                				<div class="col-md-6 text-center mb-5">
                					<h1 class="heading-section">SIGN IN</h1>
                				</div>
                			</div>
                			<div class="row justify-content-center">
                				<div class="col-md-6 col-lg-4">
                					<div class="login-wrap p-0">
                		      	<h3 class="mb-4 text-center">Have an account? Login here</h3>
                		      	<form onSubmit={handleSubmit} class="signin-form" noValidate>
                		      		<div class="form-group">
                                                  <input
                                                    className='form-control'
                                                    type='email'
                                                    name='email'
                                                    placeholder='Enter your email'
                                                    value={values.email}
                                                    onChange={handleChange}
                                                  />
                                                  {errors.email && <p class="error-validation">{errors.email}</p>}

                		      		</div>
                	                <div class="form-group">
                                                  <input
                                                    className='form-control'
                                                    type='password'
                                                    name='password'
                                                    placeholder='Enter your password'
                                                    value={values.password}
                                                    onChange={handleChange}
                                                  />
                                                  {errors.password && <p class="error-validation">{errors.password}</p>}
                	                </div>
                	                <div class="form-group">
                	            	    <button type="submit" class="form-control btn btn-primary submit px-3">Sign In</button>
                	                </div>
                	                <span className='form-input-login'>
                                              Do not have an account? <Link to='/signup'>Signup here</Link>
                                    </span>
                	            </form>
                		      </div>
                				</div>
                			</div>
                		</div>
                	</section>
            </div>

  );
};

export default SignIn;